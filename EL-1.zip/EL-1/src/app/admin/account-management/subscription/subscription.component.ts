import { Component, Inject, OnInit, DoCheck } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-subscription',
  templateUrl: './subscription.component.html',
  styleUrls: ['./subscription.component.css']
})
export class SubscriptionComponent implements OnInit,DoCheck {
  showRouting : boolean;
  showDetails: boolean;
  currentRoute:string;
  

  constructor(private _router:Router,@Inject(DOCUMENT) private document: any) { }

  ngOnInit() {
    this.showRouting = false;
    this.showDetails = true;
  }

  ngDoCheck() {
    //Called every time that the input properties of a component or a directive are checked. Use it to extend change detection by performing a custom check.
    //Add 'implements DoCheck' to the class.
    var activeUrl = this.document.location.href.substring(this.document.location.href.lastIndexOf('/') + 1);
    if(activeUrl=='addNewUsers' || activeUrl=='existingUsers')
    this.currentRoute='userMaintenance';
    else
    this.currentRoute=activeUrl;
  }
  
  searchSubscription() {
    this.showDetails = true;
    this.showRouting = true;
    this._router.navigateByUrl('/subscription/clientInfo');
    this.currentRoute='clientInfo';
  }

  navigateSubscription(route:string) {
    if(route)
    this._router.navigateByUrl('/subscription/'+route)
  }

}
