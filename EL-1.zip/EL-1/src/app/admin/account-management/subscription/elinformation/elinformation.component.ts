import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-elinformation',
  templateUrl: './elinformation.component.html',
  styleUrls: ['./elinformation.component.css']
})
export class ElinformationComponent implements OnInit {
  isEditEnabled: boolean
  constructor(private _router:Router) { }

  ngOnInit() {
    this.isEditEnabled = false;
  }
  edit() {
    this.isEditEnabled = true;
  }
  save(){
    this.isEditEnabled = false;
  }
  cancel(){
    this.isEditEnabled = false;
  }

  navigateToClientInfo() {
    this._router.navigateByUrl('/subscription/clientInfo');
  }

  navigateToUserManagement() {
    this._router.navigateByUrl('/subscription/userMaintenance');
  }
}
