import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subscription-renewal',
  templateUrl: './subscription-renewal.component.html',
  styleUrls: ['./subscription-renewal.component.css']
})
export class SubscriptionRenewalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
