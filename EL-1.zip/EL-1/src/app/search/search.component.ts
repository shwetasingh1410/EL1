import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  aClicked: boolean
  cClicked: boolean
  catClicked: boolean
  available = [{ name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }, { name: 'ABB Hongkong Limited (212323)' }, { name: 'Swiss Life (Espana) (232342)' }, { name: 'Farmers Insurance (453412)' }, { name: 'Zenith Insurance (124512)' }];
  assigned = [];

  constructor() {

  }

  ngOnInit() {
    this.aClicked = true;
    this.cClicked = false;
    this.catClicked = false;
  }
  areaClicked() {
    this.aClicked = true
    this.cClicked = false;
    this.catClicked = false;

  }
  countryClicked() {
    this.aClicked = false
    this.cClicked = true;
    this.catClicked = false;

  }
  cateClicked() {
    this.aClicked = false
    this.cClicked = false;
    this.catClicked = true;
  }
}
