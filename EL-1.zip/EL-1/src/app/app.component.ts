import { Component, OnInit, AfterViewChecked } from '@angular/core';
declare var $: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit,AfterViewChecked {
  showAdminNavigation: boolean;
  changeHeader : boolean
  constructor() {
    this.showAdminNavigation = false;
    this.changeHeader = false;
  }

  ngOnInit() {
    $('#adminElem').hover(
      () => {
        $('.nav-vertical-submenu').addClass('active');
      },
      () => {
        $('.nav-vertical-submenu').removeClass('active');
      }
    );
    $('#activeAdmin').hover(
      () => {
        $('.nav-vertical-submenu').addClass('active');
      },
      () => {
        $('.nav-vertical-submenu').removeClass('active');
      }
    );
  }

  ngAfterViewChecked() {
// window.scrollTo(0, 0);
}

  changeNavigation() {
    this.showAdminNavigation = true;
  }
  sub(){
    this.changeHeader =  true;
  }
}
