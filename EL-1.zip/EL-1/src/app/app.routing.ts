import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { SearchComponent } from './search/search.component';
import { SubscriptionComponent } from './admin/account-management/subscription/subscription.component';


const routes: Routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', component: HomeComponent },
    { path: 'search', component: SearchComponent },
    { path: 'subscription', loadChildren: 'app/admin/account-management/subscription/subscription.module#SubscriptionModule' },
    { path: 'reports', loadChildren: 'app/table/table.module#TableModule' },
    // {
    //     path: 'subscription', component: SubscriptionComponent, children: [
    //         { path: 'clientInfo', component: ClientInformationComponent },
    //         { path: 'energyLossesInfo', component: ElinformationComponent },
    //         {
    //             path: 'userMaintenance', component: UserMaintenanceComponent, children: [
    //                 { path: 'addNewUsers', component: AddNewUsersComponent },
    //                 { path: 'existingUsers', component: ExistingUsersComponent },
    //                 { path: '**', redirectTo: '\addNewUsers' },
    //             ]
    //         },
    //         { path: '**', redirectTo: '\clientInfo' },
    //     ]
    // },

];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes);