import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oee-report',
  templateUrl: './oee-report.component.html',
  styleUrls: ['./oee-report.component.css']
})
export class OeeReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
